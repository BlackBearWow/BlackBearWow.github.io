#include <windows.h>
#include <stdio.h>
void Run();
void Error(char* message);
typedef struct gameRectangle{
	float left, top, right, bottom;
}g_RECT, *pg_RECT;
g_RECT mainchar={0,0,50,50};
HDC g_hDC;
COLORREF getcolor;
typedef struct scene{
	HDC sceneDC;
	HBITMAP hImage, hOldBitmap;
	int bx, by;
	BITMAP bit;
}g_Scene;
g_Scene doraemon, background, backBuff;
 
HDC hdcMem, backgroundMem, backBuffMem;
HBITMAP hImage, hOldBitmap, bhImage, bhOldBitmap;
int bx, by, bbx, bby;
BITMAP bit, bbit;
 
HWND g_hWnd;
PAINTSTRUCT ps;
LARGE_INTEGER g_tSecond;
LARGE_INTEGER g_tTime;
float g_fDeltatime;
float gravitytime=0.f;
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		case WM_KEYDOWN:{
			switch(wParam){
				case VK_ESCAPE:{
					DestroyWindow(hwnd);
					break;
				}
			}
			break;
		}
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */
 
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
 
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+2);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */
 
	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}
 
	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Caption",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 1200, 1200, NULL,NULL,hInstance,NULL);
	g_hWnd=hwnd;
	g_hDC=BeginPaint(g_hWnd,&ps);
	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}
	backBuff.sceneDC = CreateCompatibleDC(g_hDC);
	backBuff.hImage = (HBITMAP) LoadImage(NULL, TEXT("background1.bmp"),IMAGE_BITMAP,0,0,LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	backBuff.hOldBitmap = (HBITMAP) SelectObject(backBuff.sceneDC, backBuff.hImage);
	GetObject(backBuff.hImage,sizeof(BITMAP), &backBuff.bit); backBuff.bx=backBuff.bit.bmWidth; backBuff.by=backBuff.bit.bmHeight;
	doraemon.sceneDC = CreateCompatibleDC(g_hDC);
	doraemon.hImage = (HBITMAP) LoadImage(NULL, TEXT("front.bmp"),IMAGE_BITMAP,50,50,LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	doraemon.hOldBitmap = (HBITMAP) SelectObject(doraemon.sceneDC, doraemon.hImage);
	GetObject(doraemon.hImage,sizeof(BITMAP), &doraemon.bit); doraemon.bx=doraemon.bit.bmWidth; doraemon.by=doraemon.bit.bmHeight;
	background.sceneDC = CreateCompatibleDC(g_hDC);
	background.hImage = (HBITMAP) LoadImage(NULL, TEXT("background1.bmp"),IMAGE_BITMAP,0,0,LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	background.hOldBitmap = (HBITMAP) SelectObject(background.sceneDC, background.hImage);
	GetObject(background.hImage,sizeof(BITMAP), &background.bit); background.bx=background.bit.bmWidth; background.by=background.bit.bmHeight;
	hdcMem = CreateCompatibleDC(g_hDC);
	backgroundMem = CreateCompatibleDC(g_hDC);
	backBuffMem = CreateCompatibleDC(g_hDC);
	hImage = (HBITMAP) LoadImage(NULL, TEXT("front.bmp"),IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	bhImage=(HBITMAP) LoadImage(NULL, TEXT("background1.bmp"),IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	if(hImage==NULL) Error("load image error"); if(bhImage==NULL) Error("load image error"); 
	hOldBitmap = (HBITMAP) SelectObject(hdcMem, hImage);
	bhOldBitmap = (HBITMAP) SelectObject(backgroundMem, bhImage);
	GetObject(hImage, sizeof(BITMAP), &bit); GetObject(bhImage, sizeof(BITMAP), &bbit);
    bx = bit.bmWidth;
    by = bit.bmHeight;
    bbx = bbit.bmWidth;
    bby = bbit.bmHeight;
	QueryPerformanceFrequency(&g_tSecond);//get the cpu clock frequency
	QueryPerformanceCounter(&g_tTime);
	while(1) {
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)){
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 	
		}
		else {
			Run();
		}
	}
	return msg.wParam;
}
void Run(){
	LARGE_INTEGER tTime;
	QueryPerformanceCounter(&tTime);
	g_fDeltatime=(tTime.QuadPart-g_tTime.QuadPart)/(float)g_tSecond.QuadPart;
	g_tTime=tTime;
	static float timeScale = 2.0f;
	float g_mainspeed=g_fDeltatime*300*timeScale;
	if(GetAsyncKeyState(VK_RIGHT)) { mainchar.left+=g_mainspeed; mainchar.right+=g_mainspeed; }
	else if(GetAsyncKeyState(VK_LEFT)) { mainchar.left-=g_mainspeed; mainchar.right-=g_mainspeed; }
	if(GetAsyncKeyState(VK_UP)) { mainchar.top-=g_mainspeed; mainchar.bottom-=g_mainspeed; }
	else if(GetAsyncKeyState(VK_DOWN)) { mainchar.top+=g_mainspeed; mainchar.bottom+=g_mainspeed; }
	gravitytime+=g_fDeltatime;
	getcolor=GetPixel(background.sceneDC,((int)mainchar.left+(int)mainchar.right)/2,(int)mainchar.bottom);
	if(getcolor==(255*256+255)){
		gravitytime=0; 
	}
	mainchar.top+=(5.5*gravitytime*gravitytime); mainchar.bottom+=(5.5*gravitytime*gravitytime);
	//Rectangle(g_hDC,mainchar.left,mainchar.top,mainchar.right,mainchar.bottom);
	//BitBlt(backgroundMem, mainchar.left, mainchar.top, 80, 80, hdcMem, 0, 0, SRCCOPY);
	BitBlt(backBuff.sceneDC, 0, 0, background.bx, background.by, background.sceneDC, 0, 0, SRCCOPY);
	BitBlt(backBuff.sceneDC, mainchar.left, mainchar.top, 50, 50, doraemon.sceneDC, 0, 0, SRCCOPY);
	char afe[30];
	sprintf(afe,"%d",getcolor);
	TextOut(backBuff.sceneDC,mainchar.left,mainchar.top-20,afe,strlen(afe));
	BitBlt(g_hDC, 0, 0, bbx, bby, backBuff.sceneDC, 0, 0, SRCCOPY);
}
void Error(char* message){
	MessageBox(NULL,message,"Error occured",MB_OK);
	exit(1);
}
